package controllers;

import play.mvc.*;

import views.html.*;

import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;


import models.users.*;
import models.products.*;




/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class ProductCtrl extends Controller {

    private FormFactory formFactory;
    private Environment e;
    
    @Inject
    public ProductCtrl(FormFactory f,Environment env) {
        this.formFactory = f;
        this.e = env;
        }
    // Get a user - if logged in email will be set in the session
    @Transactional
	public User getCurrentUser() {
		User u = User.getLoggedIn(session().get("email"));
		return u;
	}
    public Result index() {
        return redirect(routes.ProductCtrl.listProducts(0,""));
    }
    //public Result about() {
      //  return ok(about.render());
    //}
    
    public Result about() {
        return ok(about.render(User.getLoggedIn(session().get("email"))));
    }
    public Result contact() {
        return ok(contact.render(User.getLoggedIn(session().get("email"))));
    }
    // Get a list of products
    // If cat parameter is 0 then return all products
    // Otherwise return products for a category (by id)
    // In both cases products will be searched using the fiter value
    @Transactional
    public Result listProducts(Long cat, String filter) {
        // Get list of all categories in ascending order
        List<Category> categories = Category.findAll();
        // Instantiate products, an Array list of products			
        List<Product> products = new ArrayList<Product>();
    
        if (cat == 0) {
            // Get the list of ALL products with filter
            products = Product.findAll(filter);
        }
        else {
            // Get products for the selected category and filter (search field)
            products = Product.findFilter(cat, filter);
        }
        // Render the list products view, passing parameters
        // categories and products lists
        // category id - used for filtering
        // the filter string - this will be displayed in the filter text input
        // current user - if one is logged in
        return ok(listProducts.render(products,categories, cat, filter, getCurrentUser(),e));
    }
    public Result productDetails(Long id) {
        Product p;

        p = Product.find.byId(id);

        return ok(productDetails.render(p,User.getLoggedIn(session().get("email")),e));
    }


    
 @Security.Authenticated(Secured.class)
@Transactional
@With(CheckIfAdmin.class)
public Result deleteUser(String email) {

    // The following line of code finds the item object by id, then calls the delete() method
    // on it to have it removed from the database.

        User u = User.getUserById(email);
        u.delete();

    // Now write to the flash scope, as we did for the successful item creation.
    flash("success", "User has been deleted.");
    // And redirect to the onsale page
    return redirect(controllers.routes.ProductCtrl.users());
}
@Security.Authenticated(Secured.class)
public Result updateUser(String email) {
    User u;
    Form<User> userForm;

    try {
        // Find the item by email
        u = User.getLoggedIn(email);
        u.update();

        // Populate the form object with data from the user found in the database
        userForm = formFactory.form(User.class).fill(u);
    } catch (Exception ex) {
        return badRequest("error");
    }

    // Display the "add item" page, to allow the user to update the item
    return ok(addUser.render(userForm,User.getLoggedIn(session().get("email"))));
}

@Security.Authenticated(Secured.class)
public Result addUser() {
    Form<User> userForm = formFactory.form(User.class);
    return ok(addUser.render(userForm,User.getLoggedIn(session().get("email"))));
}
@Security.Authenticated(Secured.class)
@Transactional
public Result addUserSubmit() {
// We use the method bindFromRequest() to populate our Form<ItemOnSale> object with the
// data that the user submitted. Thanks to Play Framework, we do not need to do the messy
// work of parsing the request and extracting data from it characte by character.
Form<User> newUserForm = formFactory.form(User.class).bindFromRequest();
// We check for errors (based on constraints set in ItemOnSale class)
if (newUserForm.hasErrors()) {
    // If the form data have errors, we call the method badRequest(), requesting Play 
    // Framework to send an error response to the user and display the additem page again. 
    // As we are passing in newItemForm, the form will be populated with the data that the 
    // user has already entered, saving them from having to enter it all over again.
    return badRequest(addUser.render(newUserForm,User.getLoggedIn(session().get("email"))));
} else {
    // If no errors are found in the form data, we extract the data from the form.
    // Form objects have handy utility methods, such as the get() method we are using 
    // here to extract the data into an ItemOnSale object. This is possible because
    // we defined the form in terms of the model class ItemOnSale.
    User newUser = newUserForm.get();
    // Now we call the ORM method save() on the model object, to have it saved in the
    // database as a line in the table item_on_sale.
    
    if(User.getLoggedIn(newUser.getEmail())==null){
        newUser.save();
    }else{
        newUser.update();
    }
    // We use the flash scope to specify that we want a success message superimposed on
    // the next displayed page. The flash scope uses cookies, which we can read and set
    // using the flash() function of the Play Framework. The flash scope cookies last
    // for a single request (unlike session cookies, which we will use for log-in in a
    // future lab). So, add a success message to the flash scope.
    flash("success", "User " + newUser.getName() + " was added/updated.");
    // Having specified we want a message at the top, we can redirect to the onsale page,
    // which will have to be modified to read the flash scope and display it.
    return redirect(controllers.routes.ProductCtrl.users()); 
    }
}
public Result users() {
    List<User> userList = null;

    userList = User.findAll();

    return ok(users.render(userList,User.getLoggedIn(session().get("email"))));

 }
}